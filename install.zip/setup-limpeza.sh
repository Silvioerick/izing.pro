#!/bin/bash

echo "[+] Criando script de limpeza em /usr/local/bin/limpar-docker.sh..."
cat << 'EOF' > /usr/local/bin/limpar-docker.sh
#!/bin/bash
echo "[$(date)] Limpando imagens, volumes e redes não utilizadas..." >> /var/log/limpar-docker.log
docker container prune -f >> /var/log/limpar-docker.log 2>&1
docker image prune -a -f >> /var/log/limpar-docker.log 2>&1
docker volume prune -f >> /var/log/limpar-docker.log 2>&1
docker network prune -f >> /var/log/limpar-docker.log 2>&1
echo "[$(date)] Limpeza finalizada." >> /var/log/limpar-docker.log
EOF

chmod +x /usr/local/bin/limpar-docker.sh
echo "[+] Script tornado executável."

echo "[+] Adicionando cron job para rodar à meia-noite..."
(crontab -l 2>/dev/null; echo "0 0 * * * /usr/local/bin/limpar-docker.sh") | crontab -

echo "[✓] Tudo pronto. A limpeza será feita todo dia à meia-noite e registrada em /var/log/limpar-docker.log"

